class  StringManipulation:
  def reverse_string(self,s):
    return s[::-1]

  def capitalize_words(self,s):
    return " ".join(word.capitalize() for word in s.split())  