from library1 import MathematicalOperations
from library2 import StringManipulation
from library3 import dataHandling
from library4 import calculate_length
from library5 import calculate_area

class MyClass:
    def __init__(self):
        self.num1 = int(input("Enter the first number: ")) # Convert input to integer
        self.num2 =int(input("Enter the second number: "))  # Convert input to integer
        self.my_string = input("Enter a string: ")
        self.my_list = [10, 5, 20, 3]
        self.library1 = MathematicalOperations() 
        self.library2 = StringManipulation()
        self.library3 = dataHandling()
        self.library4 = calculate_length()
        self.library5 = calculate_area()
        

    def display_results(self):
        print("Results:")
        print(f"Addition: {self.library1.add(self.num1, self.num2)}")
        print(f"Subtraction: {self.library1.subtract(self.num1, self.num2)}")
        print(f"Multiplication: {self.library1.multiply(self.num1, self.num2)}")
        print(f"Division: {self.library1.divide(self.num1, self.num2)}")
        print(f"Reversed string: {self.library2.reverse_string(self.my_string)}")
        print(f"Capitalized words: {self.library2.capitalize_words(self.my_string)}")
        print(f"Maximum value in list: {self.library3.find_max(self.my_list)}")
        print(f"Minimum value in list: {self.library3.find_min(self.my_list)}")
        print(f"Length of word: {self.library4.length(self.my_string)}")
        print(f"Area: {self.library5.area(self.num1, self.num2)}")

if __name__ == "__main__":
    my_object = MyClass()
    my_object.display_results()