# Library 3: For data handling (example: simple list operations)
class dataHandling:
  def find_max(self,lst):
     return max(lst)

  def find_min(self,lst):
     return min(lst)