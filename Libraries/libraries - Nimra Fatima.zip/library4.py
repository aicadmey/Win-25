class calculate_length:
    def length(self,s):
        return len(s)