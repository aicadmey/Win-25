# Define four libraries (modules) within the same script

# Library 1: For mathematical operations
class MathematicalOperations:
      def add(self,x, y):
        return x + y
      def subtract(self,x, y):
        return x - y
      def multiply(self,x, y):
        return x * y
      def divide(self,x, y):
        if y == 0:
            return "Error: Division by zero"
        else:
            return x / y