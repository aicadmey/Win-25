class calculate_area:
    def area(self,x,y):
        return x * y

