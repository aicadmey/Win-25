import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

# Load dataset
df = pd.read_csv("C:/Users/user/Downloads/space_mission_dataset-file.csv")


# Set style for seaborn
sns.set_style("darkgrid")

# Function for 3D Visualization of Fuel Efficiency
def plot_fuel_efficiency():
    """3D Visualization of Fuel Efficiency"""
    fig = px.scatter_3d(df, x="Delta_V_km_s", y="Fuel_Consumption_kg", z="Mission_Duration_days", 
                         color="Mission_Duration_days", color_continuous_scale="viridis",
                         title="3D Visualization of Fuel Efficiency")
    fig.update_layout(scene=dict(
        xaxis_title='Delta V (km/s)',
        yaxis_title='Fuel Consumption (kg)',
        zaxis_title='Mission Duration (days)'))
    fig.show()

# Function to train a Linear Regression model for fuel efficiency
def train_fuel_efficiency_model():
    """Train a linear regression model for fuel efficiency"""
    X = df[["Delta_V_km_s"]]
    y = df["Fuel_Consumption_kg"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Fuel Efficiency Model (Linear Regression) MSE: {mse:.2f}")
    print(f"Fuel Efficiency Model (Linear Regression) R²: {r2:.2f}")

    # Plotting the regression line
    plt.figure(figsize=(10, 6))
    sns.regplot(x=X_test["Delta_V_km_s"], y=y_test, scatter_kws={'alpha':0.3})
    plt.title("Fuel Consumption vs Delta V (Linear Regression)")
    plt.xlabel("Delta V (km/s)")
    plt.ylabel("Fuel Consumption (kg)")
    plt.show()

# Function to train a Gradient Boosting model for fuel efficiency
def train_gradient_boosting_model():
    """Train a Gradient Boosting model for fuel efficiency"""
    X = df[["Delta_V_km_s", "Mission_Duration_days"]]
    y = df["Fuel_Consumption_kg"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Fuel Efficiency Model (Gradient Boosting) MSE: {mse:.2f}")
    print(f"Fuel Efficiency Model (Gradient Boosting) R²: {r2:.2f}")

# Function to train a Deep Neural Network (DNN) using PyTorch for fuel efficiency
def train_pytorch_dnn_fuel_efficiency():
    """Train a Deep Neural Network using PyTorch for fuel efficiency"""
    X = df[["Delta_V_km_s", "Mission_Duration_days"]]
    y = df["Fuel_Consumption_kg"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Convert to PyTorch tensors
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).reshape(-1, 1)
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).reshape(-1, 1)
    
    # Create DataLoader
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    
    # Define the PyTorch model
    class DNN(nn.Module):
        def __init__(self):
            super(DNN, self).__init__()
            self.fc1 = nn.Linear(X_train.shape[1], 64)
            self.fc2 = nn.Linear(64, 32)
            self.fc3 = nn.Linear(32, 16)
            self.fc4 = nn.Linear(16, 1)
        
        def forward(self, x):
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
            x = torch.relu(self.fc3(x))
            x = self.fc4(x)
            return x
    
    model = DNN()
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    # Train the model
    for epoch in range(50):
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
    
    # Evaluate the model
    model.eval()
    with torch.no_grad():
        y_pred_tensor = model(X_test_tensor)
        y_pred = y_pred_tensor.numpy()
    
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Fuel Efficiency Model (PyTorch DNN) MSE: {mse:.2f}")
    print(f"Fuel Efficiency Model (PyTorch DNN) R²: {r2:.2f}")

# Function to train a Scikit-learn MLP for fuel efficiency
def train_sklearn_mlp_fuel_efficiency():
    """Train a Scikit-learn MLP for fuel efficiency"""
    X = df[["Delta_V_km_s", "Mission_Duration_days"]]
    y = df["Fuel_Consumption_kg"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Train the MLP model
    model = MLPRegressor(hidden_layer_sizes=(64, 32, 16), activation='relu', solver='adam', max_iter=500)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Fuel Efficiency Model (Scikit-learn MLP) MSE: {mse:.2f}")
    print(f"Fuel Efficiency Model (Scikit-learn MLP) R²: {r2:.2f}")



# Add more features for fuel efficiency analysis
X = df[["Delta_V_km_s", "Mission_Duration_days", "Quantum_Energy_Level_eV", "Material_Density_g_cm3"]]
y = df["Fuel_Consumption_kg"]

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Gradient Boosting model
from sklearn.ensemble import GradientBoostingRegressor
model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Fuel Efficiency Model (Gradient Boosting) MSE: {mse:.2f}")
print(f"Fuel Efficiency Model (Gradient Boosting) R²: {r2:.2f}")


from torch.utils.data import DataLoader, TensorDataset


# Prepare data for fuel efficiency prediction
X = df[["Delta_V_km_s", "Mission_Duration_days"]]
y = df["Fuel_Consumption_kg"]

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 1. Train Linear Regression Model
model_lr = LinearRegression()
model_lr.fit(X_train, y_train)

# 2. Train Gradient Boosting Regressor Model
model_gb = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3)
model_gb.fit(X_train, y_train)

# 3. Train Scikit-learn MLP Regressor
model_mlp = MLPRegressor(hidden_layer_sizes=(64, 32), activation='relu', solver='adam', max_iter=500)
model_mlp.fit(X_train, y_train)

# 4. Train PyTorch DNN Model
# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert to PyTorch tensors
X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).reshape(-1, 1)
X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)

# Create DataLoader
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# Define the PyTorch model
class DNN(nn.Module):
    def __init__(self):
        super(DNN, self).__init__()
        self.fc1 = nn.Linear(X_train.shape[1], 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 16)
        self.fc4 = nn.Linear(16, 1)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x

# Initialize and train the model
model_pytorch = DNN()
criterion = nn.MSELoss()
optimizer = optim.Adam(model_pytorch.parameters(), lr=0.001)

# Train the model
for epoch in range(50):
    for batch_X, batch_y in train_loader:
        optimizer.zero_grad()
        outputs = model_pytorch(batch_X)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()

# Function to display actual vs predicted values for a given model
def display_predictions(y_test, y_pred, model_name):
    results_df = pd.DataFrame({
        'Actual Fuel Consumption (kg)': y_test,
        'Predicted Fuel Consumption (kg)': y_pred.flatten()  # Flatten if necessary
    })
    print(f"\n{model_name} Predictions:")
    print(results_df.head(10))  # Display the first 10 rows
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Mean Squared Error: {mse:.2f}")
    print(f"R² Score: {r2:.2f}")

# Generate predictions for each model
# 1. Linear Regression
y_pred_lr = model_lr.predict(X_test)
display_predictions(y_test, y_pred_lr, "Linear Regression")

# 2. Gradient Boosting Regressor
y_pred_gb = model_gb.predict(X_test)
display_predictions(y_test, y_pred_gb, "Gradient Boosting Regressor")

# 3. PyTorch DNN
model_pytorch.eval()  # Set the model to evaluation mode
with torch.no_grad():
    y_pred_pytorch_tensor = model_pytorch(X_test_tensor)
    y_pred_pytorch = y_pred_pytorch_tensor.numpy()
display_predictions(y_test, y_pred_pytorch, "PyTorch DNN")

# 4. Scikit-learn MLP Regressor
y_pred_mlp = model_mlp.predict(X_test)
display_predictions(y_test, y_pred_mlp, "Scikit-learn MLP Regressor")




# Function to train a Random Forest Classifier for celestial object classification
def train_celestial_classification_model():
    """Train a Random Forest Classifier for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Celestial Object Classification Model (Random Forest) Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

# Function to train an SVM Classifier for celestial object classification
def train_svm_classification_model():
    """Train an SVM Classifier for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    model = SVC(kernel='rbf', C=1.0, gamma='scale')
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Celestial Object Classification Model (SVM) Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

# Function to train a KNN Classifier for celestial object classification
def train_knn_classification_model():
    """Train a KNN Classifier for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    model = KNeighborsClassifier(n_neighbors=5)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Celestial Object Classification Model (KNN) Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

# Function to train a Scikit-learn MLP for celestial object classification
def train_sklearn_mlp_classification():
    """Train a Scikit-learn MLP for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Train the MLP model
    model = MLPClassifier(hidden_layer_sizes=(64, 32, 16), activation='relu', solver='adam', max_iter=500)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Celestial Object Classification Model (Scikit-learn MLP) Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

# Function to train a PyTorch DNN for celestial object classification
def train_pytorch_dnn_classification():
    """Train a PyTorch DNN for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Standardize the data
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Convert to PyTorch tensors
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train.factorize()[0], dtype=torch.long)
    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test.factorize()[0], dtype=torch.long)
    
    # Create DataLoader
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    
    # Define the PyTorch model
    class DNN(nn.Module):
        def __init__(self):
            super(DNN, self).__init__()
            self.fc1 = nn.Linear(X_train.shape[1], 64)
            self.fc2 = nn.Linear(64, 32)
            self.fc3 = nn.Linear(32, 16)
            self.fc4 = nn.Linear(16, len(y.unique()))
        
        def forward(self, x):
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
            x = torch.relu(self.fc3(x))
            x = self.fc4(x)
            return x
    
    model = DNN()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    # Train the model
    for epoch in range(50):
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
    
    # Evaluate the model
    model.eval()
    with torch.no_grad():
        y_pred_tensor = model(X_test_tensor)
        y_pred = torch.argmax(y_pred_tensor, dim=1).numpy()  # Convert to NumPy array
    
    # Convert y_test_tensor to NumPy array for compatibility with accuracy_score
    y_test_numpy = y_test_tensor.numpy()
    
    accuracy = accuracy_score(y_test_numpy, y_pred)
    print(f"Celestial Object Classification Model (PyTorch DNN) Accuracy: {accuracy:.2f}")
    print("Classification Report:")
    print(classification_report(y_test_numpy, y_pred))

def train_dl_exoplanet_model():
    """Train a neural network model for exoplanet classification"""
    df_filtered = df[df["Object_Type"] == "Exoplanet"]
    if df_filtered.empty:
        print("No Exoplanet data available for training.")
        return
    X = df_filtered[["Orbital_Period_days", "Temperature_K"]]
    y = df_filtered["Brightness_Magnitude"]  # Using Brightness_Magnitude as a proxy for habitability
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = MLPRegressor(hidden_layer_sizes=(32, 16), activation='relu', solver='adam', max_iter=1000)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    print(f"Exoplanet Model MSE: {mse:.2f}")
    print(f"Exoplanet Model R²: {r2:.2f}")   

def plot_celestial_classification():
    """Box plot for celestial object classification"""
    fig = px.box(df, x="Object_Type", y="Brightness_Magnitude", color="Object_Type",
                 title="Celestial Object Classification")
    fig.update_layout(xaxis_title='Object Type', yaxis_title='Brightness Magnitude')
    fig.show()

def train_celestial_classification_model():
    """Train a random forest classifier for celestial object classification"""
    X = df[["Brightness_Magnitude", "Temperature_K"]]
    y = df["Object_Type"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100)
    model.fit(X_train, y_train)
    score = model.score(X_test, y_test)
    print(f"Celestial Object Classification Model Accuracy: {score:.2f}")



# Filter data for exoplanets
exoplanet_data = df[df["Object_Type"] == "Exoplanet"]

# Add more features for habitability prediction
X = exoplanet_data[["Orbital_Period_days", "Temperature_K", "Molecular_Bond_Stability", "Distance_LY"]]
y = exoplanet_data["Brightness_Magnitude"]  # Use brightness as a proxy for habitability

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Gradient Boosting model
model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Exoplanet Habitability Model (Gradient Boosting) MSE: {mse:.2f}")
print(f"Exoplanet Habitability Model (Gradient Boosting) R²: {r2:.2f}")

# Filter rows with exoplanet data
exoplanet_data = df[df["Object_Type"] == "Exoplanet"]

# Set style for seaborn
sns.set_style("darkgrid")

from mpl_toolkits.mplot3d import Axes3D



# Ensure the dataset contains exoplanets
if "Object_Type" in df.columns and "Exoplanet" in df["Object_Type"].values:
    single_exoplanet = df[df["Object_Type"] == "Exoplanet"].iloc[0]
else:
    print("No exoplanets found in the dataset.")
    exit()

# Extract values
exoplanet_name = single_exoplanet.get("Exoplanet_Name", "Unknown Exoplanet")
orbital_period = single_exoplanet.get("Orbital_Period_days", np.nan)
temperature = single_exoplanet.get("Temperature_K", np.nan)
brightness = single_exoplanet.get("Brightness_Magnitude", np.nan)
exoplanet_mass = single_exoplanet.get("Mass_Jupiter", 1)
distance = single_exoplanet.get("Distance_LY", 0)

# Normalize mass size for visualization
marker_size = exoplanet_mass * 200 if pd.notna(exoplanet_mass) else 300

# Create 3D plot
fig = plt.figure(figsize=(10, 8), dpi=120)
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(orbital_period, temperature, distance, c=brightness, cmap="plasma", 
                      s=marker_size, edgecolors="black", alpha=0.9, linewidth=1.2)

# Add colorbar for Brightness Magnitude
cbar = plt.colorbar(scatter, pad=0.1)
cbar.set_label("Brightness Magnitude", fontsize=12, labelpad=10)

# Annotate with name, mass, and distance
offset = 0.5
ax.text(orbital_period, temperature + offset, distance + offset, 
        f"Name: {exoplanet_name}\nMass: {exoplanet_mass:.2f} Jupiter\nDistance: {distance} LY",
        color='white', fontsize=10, ha='center', bbox=dict(facecolor='black', alpha=0.6, edgecolor='white'))

# Labels and title
ax.set_xlabel("Orbital Period (days)", fontsize=13, color='white')
ax.set_ylabel("Temperature (K)", fontsize=13, color='white')
ax.set_zlabel("Distance (LY)", fontsize=13, color='white')
ax.set_title(f"Discovery of {exoplanet_name}", fontsize=14, pad=15, color='white')

# Add realistic space background
def darken_background(ax):
    ax.set_facecolor("#080d1f")  # Dark blue space-like background
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    for spine in ax.spines.values():
        spine.set_color("white")

darken_background(ax)

# Customize grid aesthetics
ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.3, color='white')
ax.tick_params(axis='x', colors='white')
ax.tick_params(axis='y', colors='white')
ax.tick_params(axis='z', colors='white')
cbar.ax.yaxis.set_tick_params(color='white')
plt.setp(cbar.ax.yaxis.get_ticklabels(), color='white')

# Show plot
plt.show()

# Feature importance
feature_importance = model.feature_importances_
plt.figure(figsize=(10, 6))
sns.barplot(x=feature_importance, y=X.columns)  # Removed palette argument
plt.title("Feature Importance for Exoplanet Habitability")
plt.xlabel("Importance")
plt.ylabel("Features")
plt.show()

from sklearn.neural_network import MLPRegressor

# Constants
G = 6.67430e-11  # Gravitational constant (m^3 kg^-1 s^-2)
c = 3.0e8  # Speed of light (m/s)

# Black hole parameters
name = "Supermassive Black Hole"
mass = 10  # Arbitrary mass unit (in solar masses)
distance = 5000  # Arbitrary distance unit (in light-years)
size = 500  # Image resolution
spin = 0.9  # Black hole spin parameter (0 = non-rotating, 1 = maximally rotating)

# Calculate Schwarzschild Radius (Rs = 2GM/c^2)
schwarzschild_radius = (2 * G * mass * 1.989e30) / (c**2)  # Convert solar masses to kg

# Generate black hole visualization
theta = np.linspace(0, 2 * np.pi, size)
x = np.linspace(-2, 2, size)
y = np.linspace(-2, 2, size)
X, Y = np.meshgrid(x, y)
r = np.sqrt(X**2 + Y**2)

# Modify the gravitational lensing effect based on the spin parameter
lens_factor = np.exp(-10 * (r**2) * (1 - spin))  # Spin modifies the lensing effect
black_hole = lens_factor
accretion_disk = np.exp(-20 * (r - 1)**2) * 0.7

# Simulated X-ray emissions around the accretion disk
xray_emission = np.exp(-50 * (r - 0.8)**2) * 1.2  # Bright region near the inner disk

# Simulated ML-based discovery accuracy using regression
# Synthetic dataset (mass, distance) -> accuracy
train_data = np.array([[5, 1000, 92], [10, 5000, 95], [15, 10000, 98]])  # Example dataset
X_train = train_data[:, :2]
y_train = train_data[:, 2]

# ML Model (Linear Regression)
ml_model = LinearRegression()
ml_model.fit(X_train, y_train)
predicted_ml_accuracy = ml_model.predict([[mass, distance]])[0]
predicted_ml_accuracy = round(max(85, min(predicted_ml_accuracy, 99)), 2)  # Ensure within range

# DL Model (Neural Network)
dl_model = MLPRegressor(hidden_layer_sizes=(10,), max_iter=500, random_state=42)
dl_model.fit(X_train, y_train)
predicted_dl_accuracy = dl_model.predict([[mass, distance]])[0]
predicted_dl_accuracy = round(max(85, min(predicted_dl_accuracy, 99)), 2)  # Ensure within range

# Create the figure
fig, ax = plt.subplots(figsize=(8, 8))
c = ax.imshow(accretion_disk + black_hole + xray_emission, cmap='inferno', extent=[-2, 2, -2, 2])

# Enhancements
ax.set_xlabel("X-axis (spatial units)", fontsize=12, color='white')
ax.set_ylabel("Y-axis (spatial units)", fontsize=12, color='white')
ax.set_title("Simulated Black Hole Visualization", fontsize=16, fontweight='bold', color='white')
ax.text(-1.8, 1.9, f"Name: {name}", fontsize=12, color='white')
ax.text(-1.8, 1.7, f"Mass: {mass} M_sun", fontsize=12, color='white')
ax.text(-1.8, 1.5, f"Distance: {distance} light-years", fontsize=12, color='white')
ax.text(-1.8, 1.3, f"Schwarzschild Radius: {schwarzschild_radius:.2e} m", fontsize=12, color='white')
ax.text(-1.8, 1.1, f"Spin Parameter: {spin}", fontsize=12, color='white')
ax.text(-1.8, 0.9, f"ML Discovery Accuracy: {predicted_ml_accuracy}%", fontsize=12, color='white')
ax.text(-1.8, 0.7, f"DL Discovery Accuracy: {predicted_dl_accuracy}%", fontsize=12, color='white')

# Apply dark background and show grid
plt.style.use('dark_background')
ax.grid(color='gray', linestyle='--', linewidth=0.5)
ax.spines['top'].set_color('white')
ax.spines['right'].set_color('white')
ax.spines['left'].set_color('white')
ax.spines['bottom'].set_color('white')
ax.tick_params(colors='white')

# Print information in the console
print("\nBlack Hole Information")
print("===================================")
print(f"{'Name':<25} | {name}")
print(f"{'Mass':<25} | {mass} M_sun")
print(f"{'Distance':<25} | {distance} light-years")
print(f"{'Schwarzschild Radius':<25} | {schwarzschild_radius:.2e} meters")
print(f"{'Spin Parameter':<25} | {spin}")
print(f"{'ML Discovery Accuracy':<25} | {predicted_ml_accuracy}%")
print(f"{'DL Discovery Accuracy':<25} | {predicted_dl_accuracy}%")

plt.show()


# Count the number of each object type
object_counts = df["Object_Type"].value_counts()

# Define colors for each type
colors = ["gold", "red", "blue", "purple", "green"]

# Create Pie Chart
plt.figure(figsize=(8, 8), dpi=120)
plt.pie(object_counts, labels=object_counts.index, autopct="%1.1f%%", colors=colors, startangle=140, 
        wedgeprops={'edgecolor': 'black', 'linewidth': 1.2}, textprops={'fontsize': 12})

# Title
plt.title("Distribution of Space Discoveries", fontsize=14)

# Show plot
plt.show()

from sklearn.ensemble import IsolationForest


# Select relevant columns for anomaly detection
features = ["Brightness_Magnitude", "Temperature_K", "Distance_LY", "Orbital_Period_days"]
df_filtered = df[features].dropna()  # Remove missing values

# Apply Isolation Forest for anomaly detection
iso_forest = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
df_filtered["Anomaly_Score"] = iso_forest.fit_predict(df_filtered)

# Mark anomalies
df_filtered["Anomaly"] = df_filtered["Anomaly_Score"].apply(lambda x: "Anomaly" if x == -1 else "Normal")

# Sort by brightness for better visualization
df_filtered = df_filtered.sort_values(by="Brightness_Magnitude", ascending=False).reset_index()

# Create a bar chart
plt.figure(figsize=(12, 6), dpi=120)
colors = ["red" if anomaly == "Anomaly" else "blue" for anomaly in df_filtered["Anomaly"]]
plt.bar(df_filtered.index, df_filtered["Brightness_Magnitude"], color=colors)

# Labels and title
plt.xlabel("Space Object Index")
plt.ylabel("Brightness Magnitude")
plt.title("Anomaly Detection in Space Objects (Brightness-Based)")
plt.xticks([])
plt.legend(["Normal Objects (Blue)", "Anomalies (Red)"])

# Show plot
plt.show()

# Display detected anomalies
anomalies = df_filtered[df_filtered["Anomaly"] == "Anomaly"]
print(" Detected Anomalous Space Objects:")
print(anomalies)



# Run functions

# 1. Fuel Efficiency
plot_fuel_efficiency()
train_fuel_efficiency_model()
train_gradient_boosting_model()
train_pytorch_dnn_fuel_efficiency()
train_sklearn_mlp_fuel_efficiency()

# 2. Celestial Classification
train_celestial_classification_model()
train_svm_classification_model()
train_knn_classification_model()
train_sklearn_mlp_classification()
train_pytorch_dnn_classification()
plot_celestial_classification()
train_dl_exoplanet_model()

# train_celestial_classification_model()

print("\nAnalysis and Machine Learning Models Completed!")