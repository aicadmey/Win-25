import numpy as np

class SimpleANN:
    def __init__(self, input_size):
        np.random.seed(42)
        self.input_size = input_size
        self.weights1 = np.random.randn(input_size, 128) * 0.1
        self.bias1 = np.zeros((1, 128))
        self.weights2 = np.random.randn(128, 64) * 0.1
        self.bias2 = np.zeros((1, 64))
        self.weights3 = np.random.randn(64, 32) * 0.1
        self.bias3 = np.zeros((1, 32))
        self.weights4 = np.random.randn(32, 1) * 0.1  # Fix applied here
        self.bias4 = np.zeros((1, 1))

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def relu(self, x):
        return np.maximum(0, x)

    def forward(self, X):
        self.z1 = np.dot(X, self.weights1) + self.bias1
        self.a1 = self.relu(self.z1)
        self.z2 = np.dot(self.a1, self.weights2) + self.bias2
        self.a2 = self.relu(self.z2)
        self.z3 = np.dot(self.a2, self.weights3) + self.bias3
        self.a3 = self.relu(self.z3)
        self.z4 = np.dot(self.a3, self.weights4) + self.bias4
        self.output = self.sigmoid(self.z4)
        return self.output

    def compute_loss(self, y_true, y_pred):
        return -np.mean(y_true * np.log(y_pred + 1e-8) + (1 - y_true) * np.log(1 - y_pred + 1e-8))

    def backward(self, X, y_true, lr=0.01):
        m = X.shape[ 0 ]

        # Ensure y_true is correctly shaped
        y_true = y_true.reshape(-1, 1)  # Ensure it has shape (batch_size, 1)

        # Compute output layer gradients
        dz4 = self.output - y_true  # Shape (batch_size, 1)
        dw4 = np.dot(self.a3.T, dz4) / m  # Shape (32, 1)
        db4 = np.sum(dz4, axis=0, keepdims=True) / m  # Shape (1, 1)

        # Compute hidden layer gradients
        dz3 = np.dot(dz4, self.weights4.T) * (self.a3 > 0)  # Shape (batch_size, 32)
        dw3 = np.dot(self.a2.T, dz3) / m  # Shape (64, 32)
        db3 = np.sum(dz3, axis=0, keepdims=True) / m  # Shape (1, 32)

        dz2 = np.dot(dz3, self.weights3.T) * (self.a2 > 0)  # Shape (batch_size, 64)
        dw2 = np.dot(self.a1.T, dz2) / m  # Shape (128, 64)
        db2 = np.sum(dz2, axis=0, keepdims=True) / m  # Shape (1, 64)

        dz1 = np.dot(dz2, self.weights2.T) * (self.a1 > 0)  # Shape (batch_size, 128)
        dw1 = np.dot(X.T, dz1) / m  # Shape (input_size, 128)
        db1 = np.sum(dz1, axis=0, keepdims=True) / m  # Shape (1, 128)

        # Update weights and biases
        self.weights4 -= lr * dw4
        self.bias4 -= lr * db4
        self.weights3 -= lr * dw3
        self.bias3 -= lr * db3
        self.weights2 -= lr * dw2
        self.bias2 -= lr * db2
        self.weights1 -= lr * dw1
        self.bias1 -= lr * db1

    def fit(self, X, y, epochs=100, lr=0.01):
        for epoch in range(epochs):
            y_pred = self.forward(X)
            loss = self.compute_loss(y, y_pred)
            self.backward(X, y, lr)
            if epoch % 10 == 0:
                print(f"Epoch {epoch}, Loss: {loss:.4f}")

    def predict(self, X):
        return (self.forward(X) > 0.5).astype(int)
