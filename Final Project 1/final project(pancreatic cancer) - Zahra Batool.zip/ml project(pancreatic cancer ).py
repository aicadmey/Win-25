
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

# Load dataset
df = pd.read_csv('pancreatic_cancer_dataset.csv')

# Prepare data
X = df.drop(columns=['Diagnosis'])
y = df['Diagnosis']

# Handle missing values (if any)
X.fillna(X.mean(), inplace=True)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Standardize features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train a Logistic Regression model
clf = LogisticRegression()
clf.fit(X_train, y_train)

# Predictions
y_pred = clf.predict(X_test)

# Model evaluation
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy:.4f}')
print('Classification Report:')
print(classification_report(y_test, y_pred))


# Function to take user input and predict cancer
def predict_cancer():
    print("Enter patient details for prediction:")
    user_data = []
    for feature in X.columns:
        value = float(input(f'Enter {feature}: '))
        user_data.append(value)

    user_data = np.array(user_data).reshape(1, -1)
    user_data = scaler.transform(user_data)
    prediction = clf.predict(user_data)

    if prediction[0] == 1:
        print("The model predicts that the user may have pancreatic cancer. Please consult a doctor.")
    else:
        print("The model predicts that the user is unlikely to have pancreatic cancer.")


# Run user input prediction
predict_cancer()
